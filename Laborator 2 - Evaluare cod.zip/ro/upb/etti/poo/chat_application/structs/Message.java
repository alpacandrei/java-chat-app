
package ro.upb.etti.poo.chat_application.structs;

public class Message {


    private String mSender;
    private String mContent;


    public Message(String sender, String content) {
        mSender = sender;
        mContent = content;
    }

    @Override
    public String toString() {
        return mSender + ": " + mContent;
    }
}
