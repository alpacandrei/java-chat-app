
package ro.upb.etti.poo.chat_application.structs;

public class Main {

    public static void main(String[] args) {
        
        PrivateMessage pm1 = new PrivateMessage("Ionut","Vladut","salut banana");
        PrivateMessage pm2 = new PrivateMessage("Mircea","2Pac","salut lamaie");
        PrivateMessage pm3 = new PrivateMessage("Penes","Dan","Hei hei");
        
        System.out.println(pm1.toString());
        System.out.println(pm2.toString());
        System.out.println(pm3.toString());
        
    }
}
