package ro.upb.etti.poo.chat_application.server.config;
import java.util.*;
import java.io.FileNotFoundException;
import java.io.*;

public class ServerConfig {
    
       public ServerConfig(String file) throws FileNotFoundException {
        
        FileInputStream f = new FileInputStream(file);
        Scanner scanner = new Scanner(f);
        String line;
        while(scanner.hasNext()){
            
            line = scanner.nextLine().trim();
             if(line.startsWith("#") || line.isEmpty()) {
                 continue;
                 }
        
        System.out.println(line);
    }
    
    }
}
